THE KING SHAN FAMILY TREE PROBLEM
    
MAIN FILE: GEEKTRUST.PY

INPUT FILE: SAMPLE

    ADD_CHILD Chitra Aria Female
    GET_RELATIONSHIP Lavnya Maternal-Aunt
    GET_RELATIONSHIP Aria Siblings
    ADD_CHILD Pjali Srutak Male
    GET_RELATIONSHIP Pjali Son
    ADD_CHILD Asva Vani Female
    GET_RELATIONSHIP Vasa Siblings
    GET_RELATIONSHIP Atya Sister-In-Law

HOW TO RUN THE PROJECT:
    python -m geektrust <absolute_path_to_input_file>
    
HOW TO RUN UNIT TESTCASES:
    python -m tests
        
